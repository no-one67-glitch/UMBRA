package com.umbra.privatechat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.security.SecureRandom

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(17, 21, 30)
    private val panel2 = Color.rgb(25, 31, 45)
    private val purple = Color.rgb(155, 140, 255)
    private val pale = Color.rgb(238, 240, 250)
    private val mutedColor = Color.rgb(153, 162, 183)
    private var roomCode: String? = null
    private var isHost = false
    private var muted = false
    private var secretMode = false
    private var secretRecipient = ""
    private val messages = mutableListOf<Pair<String, Boolean>>()
    private lateinit var root: LinearLayout
    private lateinit var chat: LinearLayout
    private lateinit var composer: EditText
    private lateinit var codeLabel: TextView
    private lateinit var adminBox: LinearLayout
    private lateinit var roomPanel: LinearLayout
    private lateinit var nick: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android prevents ordinary screenshots and screen recording while this window is visible.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 14f, color: Int = pale, bold: Boolean = false): TextView =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(5), dp(2), dp(5)) }
    private fun input(hintText: String): EditText = EditText(this).apply {
        hint = hintText; setHintTextColor(mutedColor); setTextColor(pale); textSize = 15f
        setSingleLine(true); setPadding(dp(14), dp(11), dp(14), dp(11)); background = rounded(panel2, 12)
    }
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(45, 52, 70)) }
    private fun button(label: String, primary: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(if (primary) Color.rgb(16, 13, 34) else pale)
        background = rounded(if (primary) purple else panel2, 12); setPadding(dp(10), dp(3), dp(10), dp(3)); setOnClickListener { action() }
    }
    private fun column(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun add(parent: LinearLayout, view: View, bottom: Int = 9) { parent.addView(view, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }) }
    private fun base(title: String, subtitle: String) {
        root = column().apply { setPadding(dp(20), dp(18), dp(20), dp(20)); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(root) }
        setContentView(scroll)
        add(root, text("◐  U M B R A", 20f, purple, true), 1)
        add(root, text("CONVERSACIONES POR INVITACIÓN", 10f, mutedColor), 18)
        add(root, text(title, 25f, pale, true), 3)
        add(root, text(subtitle, 13f, mutedColor), 18)
    }
    private fun showHome() {
        roomCode = null
        base("Tu sala, tus reglas.", "Crea una sala privada o entra con un código de seis dígitos.")
        add(root, text("TU APODO", 11f, purple, true), 3)
        nick = input("Ej. Nébula"); add(root, nick, 14)
        add(root, button("＋  Crear sala privada", true) { createRoom() })
        add(root, text("CÓDIGO DE INVITACIÓN", 11f, purple, true), 3)
        val joinCode = input("000000").apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; filters = arrayOf(android.text.InputFilter.LengthFilter(6)) }
        add(root, joinCode, 8)
        add(root, button("Entrar a una sala") {
            val c = joinCode.text.toString()
            if (c.length != 6) toast("Introduce un código de seis dígitos")
            else { toast("Modo demo: el código no verifica un servidor"); enterRoom(c, false) }
        })
        val info = text("PRIVACIDAD\nAndroid bloquea capturas normales con FLAG_SECURE. Esto no evita fotografiar la pantalla con otro dispositivo. Esta versión es una demo local: aún no conecta teléfonos ni tiene cifrado de extremo a extremo.", 12f, mutedColor)
        info.setPadding(dp(14), dp(14), dp(14), dp(14)); info.background = rounded(panel, 14); add(root, info, 0)
    }
    private fun createRoom() {
        val random = SecureRandom()
        enterRoom((100000 + random.nextInt(900000)).toString(), true)
        toast("Sala creada · comparte el código")
    }
    private fun enterRoom(code: String, host: Boolean) {
        roomCode = code; isHost = host; muted = false; secretMode = false; messages.clear(); showRoom()
    }
    private fun showRoom() {
        base("Sala privada", if (isHost) "Eres el anfitrión de esta sala." else "Sala abierta en modo demostración.")
        add(root, text("CÓDIGO DE LA SALA", 11f, mutedColor, true), 0)
        codeLabel = text(roomCode ?: "------", 27f, purple, true); add(root, codeLabel, 14)
        roomPanel = column().apply { background = rounded(panel, 16); setPadding(dp(12), dp(12), dp(12), dp(12)) } 
        chat = column(); roomPanel.addView(chat); add(root, roomPanel, 12); renderMessages()
        val composeRow = row()
        composer = input("Escribe un mensaje…").apply { imeOptions = EditorInfo.IME_ACTION_SEND; setSingleLine(true) }
        composeRow.addView(composer, LinearLayout.LayoutParams(0, dp(52), 1f))
        composeRow.addView(button("Enviar", true) { sendMessage() }, LinearLayout.LayoutParams(dp(88), dp(52)))
        add(root, composeRow, 10)
        val tools = row()
        tools.addView(button("Mensaje secreto") { if (!isHost) toast("Solo el anfitrión configura el modo secreto") else chooseSecret() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        tools.addView(button("Adjuntar") { toast("Los archivos no se almacenan en esta demo") }, LinearLayout.LayoutParams(0, dp(48), 1f))
        add(root, tools, 8)
        if (isHost) {
            add(root, button("⚙  Panel de anfitrión", true) { showAdmin() }, 8)
        }
        add(root, button("Cerrar sala y limpiar", false) { messages.clear(); showHome(); toast("Sesión local limpiada") }, 8)
        add(root, text("Demo local · otros móviles no están conectados", 11f, mutedColor), 0)
    }
    private fun sendMessage() {
        val body = composer.text.toString().trim()
        if (body.isEmpty()) return
        if (muted) { toast("El envío está silenciado"); return }
        messages.add((if (secretMode) "🔒 Para $secretRecipient: $body" else "${nick.text.toString().ifBlank { "Tú" }}: $body") to secretMode)
        composer.setText(""); secretMode = false; renderMessages()
    }
    private fun renderMessages() {
        if (!::chat.isInitialized) return
        chat.removeAllViews()
        if (messages.isEmpty()) { chat.addView(text("Los mensajes aparecerán aquí.\nEsta demo no sincroniza con otros móviles.", 13f, mutedColor)); return }
        messages.forEach { (m, secret) ->
            val tv = text(m, 14f, if (secret) purple else pale)
            tv.setPadding(dp(12), dp(10), dp(12), dp(10)); tv.background = rounded(panel2, 12)
            chat.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }
    private fun showAdmin() {
        val admin = column()
        admin.background = rounded(panel, 16); admin.setPadding(dp(14), dp(14), dp(14), dp(14))
        add(admin, text("PANEL DE ADMINISTRACIÓN", 13f, purple, true))
        add(admin, button("Borrar todos los mensajes") { messages.clear(); renderMessages(); toast("Mensajes borrados de la sesión") })
        add(admin, button("Mutear / desmutear envío") { muted = !muted; toast(if (muted) "Envío silenciado" else "Envío activado") })
        add(admin, button("Borrar multimedia") { toast("Esta demo no guarda multimedia") })
        add(admin, button("Banear miembro") { toast("El bloqueo real requiere servidor y lista de miembros") })
        add(admin, button("Elegir miembro para chat secreto") { chooseSecret() })
        add(admin, button("Finalizar sala y limpiar", false) { messages.clear(); showHome(); toast("Sala local finalizada") })
        root.addView(admin)
    }
    private fun chooseSecret() {
        val field = input("Apodo del destinatario")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)); addView(field) }
        android.app.AlertDialog.Builder(this).setTitle("Mensaje secreto").setMessage("En esta demo, el mensaje solo se etiqueta; no es privado frente a otros miembros.").setView(box)
            .setNegativeButton("Cancelar", null).setPositiveButton("Activar") { _, _ -> secretRecipient = field.text.toString().ifBlank { "miembro elegido" }; secretMode = true; toast("Modo secreto de demostración activado") }.show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { messages.clear(); super.onDestroy() }
}
