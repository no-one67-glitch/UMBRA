# UMBRA Android — proyecto inicial

Proyecto Android nativo en Kotlin con interfaz oscura, creación de sala con código de seis dígitos, entrada por código, chat local de demostración, panel de anfitrión y limpieza de mensajes al cerrar la sesión. Usa `FLAG_SECURE` para bloquear capturas de pantalla normales y grabación de pantalla en Android mientras la ventana está visible.

## Estado y límites

**Este es código fuente, no un APK compilado.** El entorno donde se generó no incluye Android SDK, Gradle instalado ni acceso a internet para descargar las herramientas necesarias; por eso no es posible compilar ni probar un APK aquí.

La app es una demostración local: no conecta dos teléfonos, no implementa cifrado de extremo a extremo, el código no se valida con un servidor, los controles de ban/mute son simulados y no hay carga real de archivos. No debe usarse para conversaciones sensibles todavía. `FLAG_SECURE` tampoco evita que alguien fotografíe la pantalla con otro dispositivo.

## Compilar

1. Instala Android Studio en un ordenador con Android SDK.
2. Abre esta carpeta como proyecto en Android Studio y deja que Gradle sincronice las dependencias.
3. Usa **Build > Build APK(s)**.
4. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/`.

Para convertirlo en una aplicación de mensajería real, falta implementar un backend autenticado, salas y membresías del lado servidor, transporte cifrado, cifrado de extremo a extremo con gestión de claves, almacenamiento temporal de medios y borrado/verificación de retención.


## Compilar automáticamente en GitHub (sin Android Studio en el móvil)

1. Crea un repositorio en GitHub y sube **todo el contenido de esta carpeta** (incluida `.github/workflows/android.yml`).
2. Abre la pestaña **Actions** del repositorio y permite GitHub Actions si te lo solicita.
3. Cada `push` inicia el flujo **Build UMBRA APK**. También puedes ejecutarlo manualmente desde Actions.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **UMBRA-debug-apk**.
5. Descomprime el artefacto; dentro estará `app-debug.apk`. Descárgalo en Android e instálalo, permitiendo la instalación desde esa fuente si el sistema lo pide.

La compilación genera un APK de depuración, no una versión firmada para publicar en Google Play. La automatización solo compila el código; no añade las funciones de servidor/cifrado que faltan.
